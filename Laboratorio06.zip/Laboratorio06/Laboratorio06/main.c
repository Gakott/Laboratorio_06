//********************************************************************************
//Universidad del Valle de Guatemala
//IE2023: Programacion de Microcontroladores
//Autor: Fernando Gabriel Caballeros Cu
//Proyecto: Laboratorio06.c
//Archivo: main.c
//Hardware: ATMega328p
//Created: 22/04/2024 12:27:37
//********************************************************************************

#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include "ADC/ADC.h"

void init_pins(void);
void init_UART9600(void);	
void write_UART(char caracter);
void writeText_UART(char* texto);

volatile char bufferRX;
volatile char leds;
volatile uint8_t menu = 0;

int main(void)
{
	init_pins();
    init_UART9600();	
	init_ADC(0, 0, 128);
	sei();
	
	//usar comilla simple
	/*write_UART('H');
	write_UART('O');
	write_UART('L');
	write_UART('A');
	write_UART(' ');
	write_UART('M');
	write_UART('U');
	write_UART('N');
	write_UART('D');
	write_UART('O');
	write_UART(' ');
	write_UART('\n');*/ 
	//usar comillas dobles
	//writeText_UART("asi como esto?");
	writeText_UART("Presione la opcion correspondiente\n");
	writeText_UART("1. Leer/Recibir caracter de un poteciometro\n");
	writeText_UART("2. Enviar un caracter Ascii\n");
	
    while (1){
		if (menu == 1){
			uint8_t valor = readADC(4);
			writeText_UART("El valor recibido fue: ");
			char str[4];
			sprintf(str, "%d", valor);
			writeText_UART(str);
			write_UART('\n');
			writeText_UART("Presione la opcion correspondiente\n");
			writeText_UART("1. Leer/Recibir caracter de un poteciometro\n");
			writeText_UART("2. Enviar un caracter Ascii\n");
			menu = 0;
		}
	}
}

void init_pins(void){
	DDRD |= 0xC0;
	DDRB |= 0x3F;
}
void init_UART9600(void){
	//Paso 1: configurar TX y RX
	DDRD &= ~(1 << DDD0);
	DDRD |= (1 << DDD1);
	//Paso 2: configurar registro A, modo Fast U2x0 = 1
	UCSR0A = 0;
	UCSR0A |= (1 << U2X0);
	//Paso 3: Configurar resgistro B, HABILITAR ISR RX, HABILITAMOS RX Y TX
	UCSR0B = 0;
	UCSR0B |= (1 << RXCIE0) | (1 << RXEN0) | (1 << TXEN0);
	//PASO 4: CONFIGURAR C > FRAME: 8 BITS DE DATOS, NO PARIDAD, 1 BIR DE STOP
	UCSR0C = 0;
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);
	//PASO 5: BAUDRATE = 9600
	UBRR0 = 207;	
}

void write_UART(char caracter){
	while(!(UCSR0A & (1 << UDRE0)));
	
	UDR0 = caracter;
}

void writeText_UART(char* texto){
	uint8_t i;
	for(i  = 0; texto[i]!= '\0'; i++){
		while(!(UCSR0A & (1 << UDRE0)));
		
		UDR0 = texto[i];
	}	
	
}


ISR(USART_RX_vect){
	bufferRX = UDR0;
	while(!(UCSR0A & (1 << UDRE0)));
	UDR0 = bufferRX;
	if (menu == 0){
		if(bufferRX == '1'){
			menu = 1;
			write_UART('\n');
			writeText_UART("Leer/Recibir un valor del potenciometro");
			write_UART('\n');
		}else if (bufferRX == '2'){
			menu = 2;
			write_UART('\n');
			writeText_UART("Enviar un caracter Ascii\n");
			writeText_UART("Ingrese el caracter que desea enviar y envielo: ");
		} else {
			writeText_UART("\nOpcion invalida\n");
			writeText_UART("\nPresione la opcion correspondiente\n");
			writeText_UART("1. Leer/Recibir caracter de un poteciometro\n");
			writeText_UART("2. Enviar un caracter Ascii\n");
		}
		}else{
			if (menu == 2){
				writeText_UART("Se muestra el caracter: ");
				leds = bufferRX;
				while (!(UCSR0A & (1<<UDRE0)));
				PORTD = 0;
				PORTB = 0;
				PORTD |= (leds << 6) & 0xC0;
				PORTB |= (leds >> 2) & 0x3F;
				UDR0 = leds;
				writeText_UART("\nPresione la opcion correspondiente\n");
				writeText_UART("1. Leer/Recibir caracter de un poteciometro\n");
				writeText_UART("2. Enviar un caracter Ascii\n");
				menu = 0;
			}
		}
		}
		